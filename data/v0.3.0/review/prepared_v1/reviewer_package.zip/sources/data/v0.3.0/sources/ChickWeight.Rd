% File src/library/datasets/man/ChickWeight.Rd
% Part of the R package, https://www.R-project.org
% Copyright 1995-2011 R Core Team
% Distributed under GPL 2 or later

\name{ChickWeight}
\docType{data}
\alias{ChickWeight}
\title{Weight Versus Age of Chicks on Different Diets}
\description{
  The \code{ChickWeight} data frame has 578 rows and 4 columns from an
  experiment on the effect of diet on early growth of chicks.
}
\usage{ChickWeight}
\format{
  An object of class
  \code{c("nfnGroupedData", "nfGroupedData", "groupedData", "data.frame")}
  containing the following columns:
  \describe{
    \item{\code{weight}}{
      a numeric vector giving the body weight of the chick (gm).
    }
    \item{\code{Time}}{
      a numeric vector giving the number of days since birth when
      the measurement was made.
    }
    \item{\code{Chick}}{
      an ordered factor with levels
      \samp{18} < \dots < \samp{48}
      giving a unique identifier for the chick.  The ordering of
      the levels groups chicks on the same diet together and
      orders them according to their final weight (lightest to
      heaviest) within diet.
    }
    \item{\code{Diet}}{
      a factor with levels \samp{1}, \dots, \samp{4} indicating which
      experimental diet the chick received.
    }
  }
}
\details{
  The body weights of the chicks were measured at birth and every
  second day thereafter until day 20.  They were also measured on day
  21.  There were four groups of chicks on different protein diets.

  This dataset was originally part of package \CRANpkg{nlme}, and that has
  methods (including for \code{[}, \code{as.data.frame}, \code{plot} and
  \code{print}) for its grouped-data classes.
}
\source{
  \bibinfo{R:Crowder+Hand:1990}{note}{Example 5.3, pages 74--78}
  \bibinfo{R:Hand+Crowder:1996}{note}{Table A.2, page 172}
  \bibshow{R:Crowder+Hand:1990,
    R:Hand+Crowder:1996,
    R:Pinheiro+Bates:2000}
}
\seealso{
  \code{\link{SSlogis}} for models fitted to this dataset.
}

\examples{
require(graphics)
coplot(weight ~ Time | Chick, data = ChickWeight,
       type = "b", show.given = FALSE)
}
\keyword{datasets}
